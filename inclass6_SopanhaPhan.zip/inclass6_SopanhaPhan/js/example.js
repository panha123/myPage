// ADD NEW ITEM TO END OF LIST
var node = document.createElement('li');
var textNode = document.createTextNode('cream');
node.appendChild(textNode);
document.getElementsByTagName('ul')[0].appendChild(node);

// ADD NEW ITEM START OF LIST
var node1 = document.createElement('li');
var textNode1 = document.createTextNode('kale');
node1.appendChild(textNode1);
var list = document.getElementsByTagName('ul')[0];
list.insertBefore(node1, list.childNodes[0]);

// ADD A CLASS OF COOL TO ALL LIST ITEMS
var nodeList = document.querySelectorAll('li');
for(var i = 0; i < nodeList.length; i++)
{
  nodeList[i].classList.add('cool');
}

// ADD NUMBER OF ITEMS IN THE LIST TO THE HEADING
var num = nodeList.length;
document.getElementsByTagName('h2')[0].innerHTML += '<span>' + num + '</span>';